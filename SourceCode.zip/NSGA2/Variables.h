/*
 *  Variables.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

//Integer maximum value
#define MAX_INTEGER 2147483647

//Integer minimum value
#define MIN_INTEGER -2147483647

//Long integer maximum value
#define MAX_LONG_INTEGER 429496729500000

//Long integer maximum value
#define MIN_LONG_INTEGER -42949672950000

//Max operation.
#define MAX(A,B) ( (A > B) ? A : B)

//Min operation.
#define MIN(A,B) ( (A < B) ? A : B)

//Equal operation.
#define EQUAL(A,B) ( (A == B) ? 1 : 0)

//Not equal operation.
#define NON_EQUAL(A,B) ( (A != B) ? 1 : 0)

//Print trace
// #define VERBOSE 1

//Activates the multiobjective approach of the genetic algorithm.
#define NSGA_II 1

//Landscape analysis by means of random sampling.
//#define RANDOM_SAMPLING 0

//Lansdscape analysis by sampling by brute force the
//#define BRUTEFORCE_SAMPLING 0
