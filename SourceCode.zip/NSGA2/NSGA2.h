//
//  NSGA2.h
//  NSGA2forQAP
//
//  Created by Josu Ceberio Uribe on 02/07/14.
//  Copyright (c) 2014 Josu Ceberio Uribe. All rights reserved.
//

#ifndef __NSGA2forQAP__NSGA2__
#define __NSGA2forQAP__NSGA2__

#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string.h>
#include <stdio.h>
#include "QAP.h"
#include "Tools.h"
#include "Population.h"

using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::ifstream;
using std::stringstream;
using std::string;

class NSGA2
{
	
public:
	
    /*
     * Problem
     */
    QAP * m_problem;
    
    /*
     * Problem size
     */
    int m_problem_size;
    
    /*
     * Maximum number of evaluations permitted in the execution.
     */
    long int m_max_evaluations;
    
    /*
     * The number of evaluations performed at the moment.
     */
    int m_evaluations;
    
    /*
     * The number of the evaluations performed to achieve the best solution so far.
     */
    int m_convergence_evaluations;
    
    /*
     * The best solution found so far from the last restart.
     */
    CIndividual * m_best;
    
    /*
     * The size of the population.
     */
    int m_pop_size;
    
    /*
     * The size of the selection pool.
     */
    int m_sel_size;
    
    /*
     * The size of the offspring population.
     */
    int m_offspring_size;
    
    /*
     * The populations of parents, childs and the mixed one.
     */
    CPopulation * m_parent_pop;
    CPopulation * m_child_pop;
    CPopulation * m_mixed_pop;
    
    /*
     * Auxiliary variables for the selection procedure.
     */
    int * m_selection_a1;
    int * m_selection_a2;
    
    /*
     * The constructor.
     */
	NSGA2(QAP * problem, int problem_size, long int max_evaluations);
	
    /*
     * The destructor.
     */
    virtual ~NSGA2();
	
    /*
     * Running function
     */
	int Run();
    
    /*
     * Returns the number of performed evaluations.
     */
	int GetPerformedEvaluations();
    
    /*
     * Returns the fitness of the best solution obtained.
     */
    int GetBestSolutionFitness();
    
    /*
     * Returns the best solution obtained.
     */
    CIndividual * GetBestSolution();
    
private:
    
    /*
     * Evaluates the individuals in the population.
     */
    void Evaluate_Pop(CPopulation * population);
    
    /*
     * Mutates the individuals in the population.
     */
    void Mutate_Pop(CPopulation * population);
    
    /*
     * Mutates the individual applying the flip mutation operator.
     */
    void Mutate_Swap(int * genes);
    
    /*
     * Mutates the individual applying the reverse mutation operator.
     */
    void Mutate_Reverse(int * genes);
    /*
     * Routine for tournament selection, it creates a new_pop from old_pop by performing tournament selection and the crossover
     */
    void Selection(CPopulation *old_pop, CPopulation *new_pop);
    
    /*
     * Crossover operator. ULX
     */
    void Crossover_ULX(CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 );

    /*
     * Crossover operator. OPX.
     */
    void Crossover_OPX(CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 );
    
    /*
     * Tournament.
     */
    CIndividual * Tournament (CIndividual * ind1, CIndividual * ind2);
    
    /*
     * Routine to merge two populations into one
     */
    void Merge(CPopulation *pop1, CPopulation *pop2, CPopulation *pop3);
    

	
};
#endif /* defined(__NSGA2forQAP__NSGA2__) */
