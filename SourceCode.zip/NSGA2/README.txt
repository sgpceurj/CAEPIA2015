In order to activate the multiobjetive approach of the genetic algorithm, in Variables.h file, the flag NSGA_II
should be uncommented.
